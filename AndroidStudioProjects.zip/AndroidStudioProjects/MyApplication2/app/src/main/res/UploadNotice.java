import android.app.Activity;

public class UploadNotice extends Activity {
}
