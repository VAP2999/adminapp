package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.myapplication.notice.NoticeData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class UploadImage extends AppCompatActivity {
    private Spinner imageCategory;
    private CardView selectImage;
    //private Button uploadImage;
    //private final int REQ = 1;
    //private View view;

    private ImageView galleryImageView;
    private EditText imageTitle;

    private final int REQ = 1;
    private Bitmap bitmap;

    private String category,title;
    //private String[] items;


    private Button uploadImageBtn;
    private DatabaseReference reference,dbRef;
    private StorageReference storageReference;
    String downloadUrl="";
    private ProgressDialog pd;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_image);
        reference= FirebaseDatabase.getInstance().getReference().child("Image");
        storageReference= FirebaseStorage.getInstance().getReference();
        pd=new ProgressDialog(this );

        selectImage=findViewById(R.id.addGalleryImage);
        imageCategory=findViewById(R.id.image_category);
        uploadImageBtn=findViewById(R.id.uploadImageBtn);

        galleryImageView=findViewById(R.id.galleryImageView);
        String[] vap =new String[]{"Select Category","TechFest","CulturalFest","Other Events"};

        try{
        imageCategory.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,vap));
        imageCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){


            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category= imageCategory.getSelectedItem().toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {



            }
        });

        }catch (NullPointerException ex){
            ex.printStackTrace();
        }
        try {

            selectImage.setOnClickListener(v -> openGallery());
        }catch (NullPointerException ex) {
            ex.printStackTrace();
        }


        //selectImage = findViewById(R.id.addImage);
        galleryImageView = findViewById(R.id.galleryImageView);
        //imageTitle=findViewById(R.id.imageTitle);
        uploadImageBtn=findViewById(R.id.uploadImageBtn);

        try {
            selectImage.setOnClickListener(v -> openGallery());
            uploadImageBtn.setOnClickListener(v -> {


                if (bitmap == null) {
                    uploadData(downloadUrl);
                } else {
                    uploadImage();
                }
            });
        }catch (NullPointerException ex) {
            ex.printStackTrace();
        }
    }



    private void uploadImage() {
        pd.setMessage("Uploading...");
        pd.show();
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50,baos);
        byte[]finalimg=baos.toByteArray();
        final StorageReference filepath;
        filepath=storageReference.child("Image").child(finalimg+"JPG");
        final UploadTask uploadTask=filepath.putBytes(finalimg);
        uploadTask.addOnCompleteListener(UploadImage.this, task -> {
            if(task.isSuccessful()){
                uploadTask.addOnSuccessListener(taskSnapshot -> filepath.getDownloadUrl().addOnSuccessListener(uri -> {
                    downloadUrl=String.valueOf(uri);
                    uploadData(downloadUrl);

                }));
            }else{
                pd.dismiss();
                Toast.makeText(UploadImage.this, "successfull", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void uploadData(String downloadUrl) {
        dbRef=reference.child(category);
        final String uniqueKey =dbRef.push().getKey();
        //String title=imageTitle.getText().toString();
        Calendar calForDate=Calendar.getInstance();
        SimpleDateFormat currentDate= new SimpleDateFormat("dd-MM-yy");
        String date =currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime= new SimpleDateFormat("hh:mm a");
        String time =currentTime.format(calForDate.getTime());

        ImageData noticeData=new ImageData(title,downloadUrl,date,time,uniqueKey);


        dbRef.child(uniqueKey).setValue(noticeData).addOnSuccessListener(unused -> {
            pd.dismiss();
            Toast.makeText(UploadImage.this, "successful", Toast.LENGTH_SHORT).show();

        }).addOnFailureListener(e -> {
            pd.dismiss();
            Toast.makeText(UploadImage.this, "something went wrong", Toast.LENGTH_SHORT).show();
        });

    }

    private void openGallery() {
        Intent pickImage=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickImage,REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ && resultCode == RESULT_OK){
            assert data != null;
            Uri uri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            galleryImageView.setImageBitmap(bitmap);


        }
    }
}
