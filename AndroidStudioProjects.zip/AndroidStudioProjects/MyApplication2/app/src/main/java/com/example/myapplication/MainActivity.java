package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication.Faculty.UpdateFaculty;
import com.example.myapplication.notice.DeleteNoticeActivity;
import com.example.myapplication.notice.UploadNotice;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    CardView uploadNotice;
    CardView addGalleryImage,addEBook,Faculty,DeleteNotice;




    //Button button, button1, button2;


    @SuppressLint("MissingInflatedId")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //button = findViewById(R.id.addNotice);
        //button1 = findViewById(R.id.addImage);
        //button = findViewById(R.id.addFaculty);
        uploadNotice = findViewById(R.id.addNotice);
        uploadNotice.setOnClickListener(this);
        addGalleryImage = findViewById(R.id.addGalleryImage);
        addGalleryImage.setOnClickListener(this);
        addEBook = findViewById(R.id.addEBook);
        addEBook.setOnClickListener(this);
        Faculty = findViewById(R.id.Faculty);
        DeleteNotice = findViewById(R.id.DeleteNotice);
        Faculty.setOnClickListener(this);
        DeleteNotice.setOnClickListener(this);


    }


    public void onClick(View view) {

        //Intent intent = new Intent(MainActivity.this, UploadNotice.class);

        //startActivity(intent);
        //Intent intent1 = new Intent(MainActivity.this, UploadImage.class);

        //startActivity(intent1);
        //Intent intent3 = new Intent(MainActivity.this, UploadFaculty.class);

        //startActivity(intent3);
        Intent intent;
        switch (view.getId()) {

            case R.id.addNotice:
                intent = new Intent(MainActivity.this, UploadNotice.class);
                startActivity(intent);
                break;
            case R.id.addGalleryImage:
                intent = new Intent(MainActivity.this, UploadImage.class);
                startActivity(intent);
                break;
            case R.id.addEBook:
                intent = new Intent(MainActivity.this, UploadPdfActivity.class);
                startActivity(intent);
                break;
            case R.id.Faculty:
                intent = new Intent(MainActivity.this, UpdateFaculty.class);
                startActivity(intent);
                break;
            case R.id.DeleteNotice:
                intent = new Intent(MainActivity.this, DeleteNoticeActivity.class);
                startActivity(intent);
                break;
        }


    }















}














