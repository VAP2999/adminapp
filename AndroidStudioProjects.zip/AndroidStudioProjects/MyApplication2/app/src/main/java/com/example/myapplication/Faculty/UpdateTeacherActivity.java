package com.example.myapplication.Faculty;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;

public class UpdateTeacherActivity extends AppCompatActivity {
    private ImageView updateTeacherImage;
    private EditText updateTeacherName,updateTeacherEmail,updateTeacherPost;
    private Button updateTeacherBtn,deleteTeacherBtn;
    private String name,email,post,image;
    private final int   REQ=1;
    private String downloadUrl,category,uniqueKey;
    private Bitmap bitmap=null;
    private ProgressDialog pd;
    private DatabaseReference reference,dbRef;
    private StorageReference storageReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_teacher2);

        name=getIntent().getStringExtra("name");
        email=getIntent().getStringExtra("email");
        post=getIntent().getStringExtra("post");
        image=getIntent().getStringExtra("image");

        uniqueKey=getIntent().getStringExtra("key");
        category=getIntent().getStringExtra("category");


        updateTeacherName=findViewById(R.id.updateTeacherName);
        updateTeacherImage=findViewById(R.id.updateTeacherImage);
        updateTeacherEmail=findViewById(R.id.updateTeacherEmail);
        updateTeacherPost=findViewById(R.id.updateTeacherPost);
        updateTeacherBtn=findViewById(R.id.updateTeacherBtn);
        deleteTeacherBtn=findViewById(R.id.deleteTeacherBtn);

        reference= FirebaseDatabase.getInstance().getReference();
        storageReference= FirebaseStorage.getInstance().getReference();
        pd=new ProgressDialog(this );

        try {
            Picasso.get().load(image).into(updateTeacherImage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        updateTeacherEmail.setText(email);
        updateTeacherName.setText(name);
        updateTeacherPost.setText(post);

        updateTeacherImage.setOnClickListener(v -> openGallery());
        updateTeacherBtn.setOnClickListener(v -> {
            name=updateTeacherName.getText().toString();
            email=updateTeacherEmail.getText().toString();
            post=updateTeacherPost.getText().toString();
            checkValidation();
        });
        deleteTeacherBtn.setOnClickListener(v -> deleteData());
    }

    private void checkValidation() {
        if(name.isEmpty()){
            updateTeacherName.setError("Empty");
            updateTeacherName.requestFocus();
        }else if(email.isEmpty()){
            updateTeacherEmail.setError("Empty");
            updateTeacherEmail.requestFocus();
        }else if(post.isEmpty()){
            updateTeacherPost.setError("Empty");
            updateTeacherPost.requestFocus();
        }else if(bitmap==null){
            updateData(image);
        }else{
            uploadImage();
        }
    }

    private void updateData(String s) {
        HashMap<String, Object> hp= new HashMap<>();
        hp.put("name",name);
        hp.put("email",email);
        hp.put("post",post);
        hp.put("image",s);


        dbRef.child("update faculty").child(uniqueKey).updateChildren(hp).addOnSuccessListener(o -> {
            Toast.makeText(UpdateTeacherActivity.this, "update successfull", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(UpdateTeacherActivity.this,UpdateFaculty.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }).addOnFailureListener(e -> Toast.makeText(UpdateTeacherActivity.this, "something went wrong", Toast.LENGTH_SHORT).show());
    }

    private void uploadImage() {
        pd.setMessage("Uploading...");
        pd.show();
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50,baos);
        byte[]finalimg=baos.toByteArray();
        final StorageReference filepath;
        filepath=storageReference.child("Teachers").child(finalimg+"JPG");
        final UploadTask uploadTask=filepath.putBytes(finalimg);
        uploadTask.addOnCompleteListener(UpdateTeacherActivity.this, task -> {
            if(task.isSuccessful()){
                uploadTask.addOnSuccessListener(taskSnapshot -> filepath.getDownloadUrl().addOnSuccessListener(uri -> {
                    downloadUrl=String.valueOf(uri);
                    updateData(downloadUrl);

                }));
            }else{
                pd.dismiss();
                Toast.makeText(UpdateTeacherActivity.this, "successfull", Toast.LENGTH_SHORT).show();
            }
        });

    }


    private void deleteData() {
        dbRef.child(category).child(uniqueKey).removeValue()
                .addOnCompleteListener(task -> {
                    Toast.makeText(UpdateTeacherActivity.this, "deleted successfull", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(UpdateTeacherActivity.this,UpdateFaculty.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);


                }).addOnFailureListener(e -> Toast.makeText(UpdateTeacherActivity.this, "something went wrong", Toast.LENGTH_SHORT).show());
    }

    private void openGallery() {
        Intent pickImage=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickImage,REQ);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ && resultCode == RESULT_OK){
            assert data != null;
            Uri uri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            updateTeacherImage.setImageBitmap(bitmap);


        }
    }
}